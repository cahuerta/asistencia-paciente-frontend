import FormPaciente from './components/FormPaciente';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <FormPaciente />
    </div>
  );
}

export default App;
